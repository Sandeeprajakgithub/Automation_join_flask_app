from flask import Flask, render_template, request, redirect, url_for, send_file
import pandas as pd
import io
import tempfile

app = Flask(__name__)

# I have created one temprary variable here
result_set = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/download_excel')
def download_excel():
    global result_set

    if result_set is None:
        return "Result set not found. Please perform the operation first."

    #Here I am Saving the DataFrame to an Excel file
    with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as temp_file:
        result_set.to_excel(temp_file.name, index=False)

    # Now this is responsing to Serve the temporary Excel file for download
    

@app.route('/process', methods=['POST'])
def process():
    global result_set

    # My existing processing logic for Excel files and join
    file1 = request.files['file1']
    file2 = request.files['file2']
    join_type = request.form['join_type']
    common_column = request.form['common_column']

    if file1 and file2:

        df1 = pd.read_excel(file1)
        df2 = pd.read_excel(file2)

        print("Columns in df1:", df1.columns)
        print("Columns in df2:", df2.columns)
        print("Common column:", common_column)
        print("Join type:", join_type)

        result_set = pd.merge(df1, df2, how=join_type, on=common_column)

        result_html = result_set.to_html(index=False) 
        
        return render_template('result.html', result=result_html)
    else:
        return render_template('index.html', error="Please upload both files.")

@app.route('/redirect_to_index')
def redirect_to_index():
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
